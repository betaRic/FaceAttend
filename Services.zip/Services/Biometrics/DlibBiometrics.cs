﻿using System;
using System.IO;
using System.Linq;
using System.Web.Hosting;
using FaceAttend.Services;
using FaceRecognitionDotNet;

namespace FaceAttend.Services.Biometrics
{
    public class DlibBiometrics
    {
        public class FaceBox
        {
            public int Left { get; set; }
            public int Top { get; set; }
            public int Width { get; set; }
            public int Height { get; set; }
        }

        private static readonly object _lock = new object();
        private static FaceRecognition _fr;
        private static Model _model;

        public DlibBiometrics()
        {
            EnsureInit();
        }

        private static void EnsureInit()
        {
            if (_fr != null) return;

            lock (_lock)
            {
                if (_fr != null) return;

                var modelsDir = AppSettings.GetString("Biometrics:DlibModelsDir", "~/App_Data/models/dlib");
                var detector = AppSettings.GetString("Biometrics:DlibDetector", "hog");

                var absModelsDir = HostingEnvironment.MapPath(modelsDir);
                if (string.IsNullOrWhiteSpace(absModelsDir) || !Directory.Exists(absModelsDir))
                    throw new InvalidOperationException("Dlib models directory not found: " + modelsDir);

                _fr = FaceRecognition.Create(absModelsDir);

                _model = detector.Equals("cnn", StringComparison.OrdinalIgnoreCase)
                    ? Model.Cnn
                    : Model.Hog;
            }
        }

        public FaceBox[] DetectFacesFromFile(string imagePath)
        {
            EnsureInit();
            lock (_lock)
            {
                using (var img = FaceRecognition.LoadImageFile(imagePath))
                {
                    // use 0 upsample to avoid instability on some machines
                    var locs = _fr.FaceLocations(img, numberOfTimesToUpsample: 0, model: _model).ToArray();

                    return locs.Select(l => new FaceBox
                    {
                        Left = l.Left,
                        Top = l.Top,
                        Width = Math.Max(0, l.Right - l.Left),
                        Height = Math.Max(0, l.Bottom - l.Top)
                    }).ToArray();
                }
            }
        }

        public double[] GetSingleFaceEncodingFromFile(string imagePath, out string error)
        {
            error = null;
            EnsureInit();

            lock (_lock)
            {
                using (var img = FaceRecognition.LoadImageFile(imagePath))
                {
                    var locs = _fr.FaceLocations(img, numberOfTimesToUpsample: 0, model: _model).ToArray();
                    if (locs.Length == 0) { error = "NO_FACE"; return null; }
                    if (locs.Length > 1) { error = "MULTI_FACE"; return null; }

                    var enc = _fr.FaceEncodings(img, new[] { locs[0] }).FirstOrDefault();
                    if (enc == null) { error = "ENCODING_FAIL"; return null; }

                    return enc.GetRawEncoding();
                }
            }
        }

        public static double Distance(double[] a, double[] b)
        {
            if (a == null || b == null || a.Length != b.Length) return double.PositiveInfinity;
            double sum = 0;
            for (int i = 0; i < a.Length; i++)
            {
                double d = a[i] - b[i];
                sum += d * d;
            }
            return Math.Sqrt(sum);
        }

        public static byte[] EncodeToBytes(double[] v)
        {
            if (v == null || v.Length != 128) return null;
            var bytes = new byte[128 * 8];
            for (int i = 0; i < 128; i++)
            {
                var b = BitConverter.GetBytes(v[i]);
                Buffer.BlockCopy(b, 0, bytes, i * 8, 8);
            }
            return bytes;
        }

        public static double[] DecodeFromBytes(byte[] bytes)
        {
            if (bytes == null || bytes.Length != 128 * 8) return null;
            var v = new double[128];
            for (int i = 0; i < 128; i++)
            {
                v[i] = BitConverter.ToDouble(bytes, i * 8);
            }
            return v;
        }
    }
}
